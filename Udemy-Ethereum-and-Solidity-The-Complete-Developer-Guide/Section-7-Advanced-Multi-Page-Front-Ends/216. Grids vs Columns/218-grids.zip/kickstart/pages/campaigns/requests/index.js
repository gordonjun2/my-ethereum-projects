import React, { Component } from "react";

class RequestIndex extends Component {
  render() {
    return <h3>Request List</h3>;
  }
}

export default RequestIndex;
